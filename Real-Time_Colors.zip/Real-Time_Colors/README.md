# Real-Time Colors

Create a socket application that presents the user with 3 buttons for color options. When a user clicks on one of the color options, all currently connected socket users should have their entire background change to that color.

BONUS: As soon as a new user connects to our server, update their color with the most recent color previously selected by the last user.
