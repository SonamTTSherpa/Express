# EJS Cat Data

In this assignment, we are going to focus on displaying data about our particular cats.

As before, when we navigate to localhost:8000/cats, we should see pictures of all our cats. This time, when we click the pictures, they will navigate us to a unique route in the server. This route may be hardcoded for now.

For each of the cat's routes, serve the same template, details.ejs. However, each route should send different data to the template so that the page is customized for each cat. Again, this data may be hardcoded in the server since we do not have a database yet. Include at least one array in the cat's data so that you may practice iterating over an array in the template.
